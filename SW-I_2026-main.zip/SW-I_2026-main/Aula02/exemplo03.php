<?php
    $a = 3;
    $b = 7;
    echo "Resultado: " . ($a % $b);

    echo "<hr>";

    $x = true;
    $y = false;

    $result = $x && $y;

    echo"Resultado: $result";

?>