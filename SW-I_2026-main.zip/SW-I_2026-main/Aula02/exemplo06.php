<?php 
    $a = 4;
    $b = 3;
    // Aqui entra o if para verificar o denominador
    if ($b==0){
        echo"Não é possivel dividir";
    }else{
      $r = $a / $b;
      echo "$r";
    }
    echo"<br>";
    echo "Aqui continua o seu programa...";

?>

