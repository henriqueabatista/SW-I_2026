<?php
    echo "<h1>OLÁ MUNDO</h1>"; //adicionar título
    echo "<br>";
    echo "outro teste";
?>