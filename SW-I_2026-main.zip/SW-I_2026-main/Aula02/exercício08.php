<?php
    $pre = "hiper";
    echo "${pre}texto";
    //alternativa D = echo "${pre}texto"
?>