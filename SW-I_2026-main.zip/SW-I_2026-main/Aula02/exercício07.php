<?php
    $a = "Casal 20";
    $b = 10;
    $c = $a + $b;
    echo $c;
    
    //Alternativa D = erro
?>
