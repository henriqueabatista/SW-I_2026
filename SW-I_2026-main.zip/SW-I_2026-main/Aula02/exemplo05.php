<?php 
    $a = 4;
    $b = "101 Dalmatas";

    $s = $a + $b;

    echo $s;

?>
