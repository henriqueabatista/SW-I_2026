<?php
    $idade = 18;
    if($idade>=18){
        echo"Maior de idade";
    }else{
        echo"Menor de idade";
    }
?>