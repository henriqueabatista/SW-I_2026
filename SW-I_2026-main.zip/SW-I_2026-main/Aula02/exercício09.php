<?php
    $x = "P";
    $y = "H";
    $z = "$x$y$x";
    echo $z;
?>